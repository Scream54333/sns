api_id = '22030047'
api_hash = 'b9b3d65b4c1b11b86bd617f19da634bd'
bot_token = '8003974290:AAEbMCeRolrBOqMd1PWU0zAbWGe4O-WTKZ4'
admin_chat_ids = [5642501243]  # Добавьте сюда ID всех администраторов 'id', 'id' и тд
CRYPTO_PAY_TOKEN = 'lmao' # тут замените на свой api от бота @send

senders = {
    "huyznaet06@gmail.com": "cyeb pnyi ctpj xxdx",
    "alabuga793@gmail.com": "tzuk rehw syaw ozme",
    
"dlatt6677@gmail.com": "usun ruef otzx zcrh",
"edittendo0@gmail.com": "mzdl lrmx puyq epur",
"shshsbsbsbwbwvw@gmail.com": "jqrx qivo qxjy jejt",
"IvanKarma2000@gmail.com": "irlr cggo xksq tlbb",
"misha28272727@gmail.com": "kgwqxvkgjyccibkm",
"vladimiradmiralov664@gmail.com": "papq hkip geao rkuz",
"trevorzxasuniga214@gmail.com": "egnr eucw jvxg jatq",
"dellapreston50@gmail.com": "qoit huon rzsd eewo",
"neilfdhioley765@gmail.com": "rgco uwiy qrdc gvqh",
"samuelmnjassey32@gmail.com": "lgct cjiw nufr zxjg",
"segapro72@gmail.com": "ubmq pbrt ujqy orhf",
"kurokopotok@gmail.com": "pxww ewut uffz ufpu",
"kalievutub@gmail.com": "jlwb otxo mppi jvdh",
"snosakka07@gmail.com": "yiro khva gafc lujr",
"prosega211@gmail.com": "fnrz rkrp nrwy yaig",
"qwaerlarp@gmail.com": "zrzx siyf ukvm ctjp",
"segatel093@gmail.com": "fsma qetz gvmp pqrm",
"irina15815123@gmail.com": "fmre mxne ncaw gnke",
"disgeugh482@gmail.com": "ufet dwko fadg crax",
"germanalexandrovich12345678@gmail.com": "tsln hvmz mipp kmwh",
"bl89222099674@gmail.com": "yjru yftj zihu nyrz",
"psega0892@gmail.com": "vhrr hiso npgm xnoi",
"noakk1843@gmail.com": "mvqo rfrv cjht vppo",
"mak091ov@gmail.com": "hhli muyx nqju wlkk",
"ilya228smirn0@gmail.com": "faex guxl rlsx tvyc",
"demidivivan548@gmail.com": "izky pqsm xmxk vgod",
"zedrenskijvitalij@gmail.com": "javb kkcu znxe ykdj",
"tatanamorinskaa@gmail.com": "cjig kaxt tijl ndre",
"ivanplutalov543@gmail.com": "xsvm ewki dhfz qqkh",
"editt1345@gmail.com": "hezf xuel hzvz jzur",
"dlatt7055@gmail.com": "tpzd nxle odaw uqwf",
"dlyabravla655@gmail.com": "kprn ihvr bgia vdys",
"allisonikse1922@gmail.com": "tozo xrzu qndn mwuq"
}

receivers = [
    'sms@telegram.org', 'dmca@telegram.org', 'abuse@telegram.org', 'sticker@telegram.org', 'support@telegram.org', 'support@telegram.org', 'dmca@telegram.org', 'security@telegram.org', 'sms@telegram.org', 'info@telegram.org', 'marta@telegram.org', 'spam@telegram.org', 'alex@telegram.org', 'abuse@telegram.org', 'pavel@telegram.org', 'durov@telegram.org', 'elies@telegram.org', 'ceo@telegram.org', 'mr@telegram.org', 'levlam@telegram.org', 'perekopsky@telegram.org', 'recover@telegram.org', 'germany@telegram.org', 'hyman@telegram.org', 'qa@telegram.org', 'Stickers@telegram.org', 'ir@telegram.org', 'vadim@telegram.org', 'shyam@telegram.org', 'stopca@telegram.org', '>support@telegram.org', 'ask@telegram.org', '125support@telegram.org', 'me@telegram.org', 'enquiries@telegram.org', 'api_support@telegram.org', 'marketing@telegram.org', 'ca@telegram.org', 'recovery@telegram.org', 'http@telegram.org', 'corp@telegram.org', 'corona@telegram.org', 'ton@telegram.org', 'sticker@telegram.org'
]



smtp_servers = {
    "gmail.com": ("smtp.gmail.com", 587),
    "yandex.ru": ("smtp.yandex.ru", 465),
    "mail.ru": ("smtp.mail.ru", 465),
    "rambler.ru": ("smtp.rambler.ru", 465),
    "yahoo.com": ("smtp.mail.yahoo.com", 465),
    "outlook.com": ("smtp.office365.com", 587),
    "icloud.com": ("smtp.mail.me.com", 587),
    "aol.com": ("smtp.aol.com", 587),
    "zoho.com": ("smtp.zoho.com", 587),
    "protonmail.com": ("smtp.protonmail.com", 587),
    "t-online.de": ("secure.emailsrvr.com", 587),
    "gmx.de": ("mail.gmx.com", 587),
    "hotmail.de": ("smtp.live.com", 587),
    "web.de": ("smtp.web.de", 587),
    "gmx.net": ("mail.gmx.net", 587),
    "posteo.de": ("posteo.de", 587),
    "mailbox.org": ("smtp.mailbox.org", 587),
    "1und1.de": ("smtp.1und1.de", 587),
    "strato.de": ("smtp.strato.de", 465),
    "fastmail.com": ("smtp.fastmail.com", 587),
    "tutanota.com": ("smtp.tutanota.de", 587),
    "runbox.com": ("smtp.runbox.com", 587),
    "hushmail.com": ("smtp.hushmail.com", 587),
    "countermail.com": ("smtp.countermail.com", 465),
    "lavabit.com": ("smtp.lavabit.com", 465),
    "cock.li": ("mail.cock.li", 587),
    "migadu.com": ("smtp.migadu.com", 587),
    "mailfence.com": ("smtp.mailfence.com", 587),
    "kolabnow.com": ("smtp.kolabnow.com", 587),
    "mailnesia.com": ("smtp.mailnesia.com", 587),
    "mailcatch.com": ("smtp.mailcatch.com", 587),
    "mintemail.com": ("smtp.mintemail.com", 587),
    "spamgourmet.com": ("smtp.spamgourmet.com", 587),
    "mytemp.email": ("smtp.mytemp.email", 587),
    "temp-mail.org": ("smtp.temp-mail.org", 587),
    "mailtemp.info": ("smtp.mailtemp.info", 587),
    "fakemail.net": ("smtp.fakemail.net", 587),
    "sharklasers.com": ("smtp.sharklasers.com", 587)
}

